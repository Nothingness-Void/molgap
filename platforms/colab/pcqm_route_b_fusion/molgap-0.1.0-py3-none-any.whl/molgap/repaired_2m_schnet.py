"""Shard-streamed repaired-2M SchNet training for accepted ETKDG views."""

from __future__ import annotations

import copy
import hashlib
import json
import os
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch_geometric.loader import DataLoader

from .repaired_2m_3d_colab import (
    ROUTE_B_SCHNET_CONFIG,
    atomic_json,
    atomic_torch_save,
    export_embeddings,
)
from .schnet import SchNetWrapper


@dataclass(frozen=True)
class Repaired2MSchNetConfig:
    variant: str
    epochs: int = 20
    patience: int = 6
    batch_size: int = 128
    learning_rate: float = 2.1150972021685588e-4
    weight_decay: float = 1.4656553886225336e-5
    grad_clip: float = 10.0
    seed: int = 42
    source_rows: int = 2_000_000
    num_workers: int = 0

    def __post_init__(self) -> None:
        if self.variant not in {"primary", "augmented"}:
            raise ValueError("variant must be primary or augmented")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def source_roles(source_rows: int, seed: int) -> np.ndarray:
    permutation = np.random.default_rng(seed).permutation(source_rows)
    n_train = int(0.8 * source_rows)
    n_validation = int(0.1 * source_rows)
    roles = np.full(source_rows, 2, dtype=np.int8)
    roles[permutation[:n_train]] = 0
    roles[permutation[n_train : n_train + n_validation]] = 1
    return roles


def _source_idx(graph) -> int:
    value = int(graph.source_idx.view(-1)[0])
    return value


def _role_graphs(graphs: list, roles: np.ndarray, role: int) -> list:
    selected = []
    for graph in graphs:
        index = _source_idx(graph)
        if index < 0 or index >= len(roles):
            raise ValueError(f"source_idx {index} outside split contract")
        if int(roles[index]) == role:
            selected.append(graph)
    return selected


def _graph_paths(graph_dir: Path) -> list[Path]:
    paths = sorted(graph_dir.glob("graphs_*.pt"))
    if len(paths) != 100:
        raise RuntimeError(f"expected 100 graph shards in {graph_dir}, got {len(paths)}")
    return paths


def _accept_view(graph_dir: Path, acceptance_path: Path) -> dict:
    payload = json.loads(acceptance_path.read_text(encoding="utf-8"))
    if payload.get("accepted") is not True:
        raise RuntimeError(f"view is not accepted: {acceptance_path}")
    paths = _graph_paths(graph_dir)
    if int(payload.get("expected_shards", -1)) != len(paths):
        raise RuntimeError("acceptance shard count differs from graph cache")
    return {
        "acceptance_path": str(acceptance_path),
        "acceptance_sha256": sha256_file(acceptance_path),
        "accepted_rows": int(payload["accepted_rows"]),
        "shards": len(paths),
    }


def _set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def _forward(model: nn.Module, batch) -> torch.Tensor:
    charges = batch.charges if hasattr(batch, "charges") else None
    return model(batch.z, batch.pos, batch.batch, charges=charges)


@torch.no_grad()
def _evaluate_role(
    *,
    model: nn.Module,
    graph_paths: list[Path],
    roles: np.ndarray,
    role: int,
    device: torch.device,
    batch_size: int,
    num_workers: int,
) -> tuple[np.ndarray, int]:
    model.eval()
    absolute_error = torch.zeros(3, dtype=torch.float64)
    count = 0
    for path in graph_paths:
        graphs = torch.load(path, map_location="cpu", weights_only=False)
        selected = _role_graphs(graphs, roles, role)
        del graphs
        if not selected:
            continue
        loader = DataLoader(
            selected,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
        )
        for batch in loader:
            batch = batch.to(device, non_blocking=True)
            with torch.amp.autocast("cuda"):
                prediction = _forward(model, batch)
            target = batch.y.view(-1, 3)
            absolute_error += (
                prediction.float().sub(target).abs().sum(dim=0).double().cpu()
            )
            count += int(batch.num_graphs)
        del loader, selected
    if count == 0:
        raise RuntimeError("evaluation role is empty")
    return (absolute_error / count).numpy(), count


def preflight_repaired_2m_schnet(
    *,
    primary_graph_dir: Path,
    primary_acceptance: Path,
    secondary_graph_dir: Path | None,
    secondary_acceptance: Path | None,
    variant: str,
    output_path: Path,
    batch_size: int = 16,
) -> dict:
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for repaired-2M SchNet preflight")
    config = Repaired2MSchNetConfig(variant=variant, batch_size=batch_size)
    reports = {"primary": _accept_view(primary_graph_dir, primary_acceptance)}
    if variant == "augmented":
        if secondary_graph_dir is None or secondary_acceptance is None:
            raise ValueError("augmented preflight requires the secondary view")
        reports["secondary"] = _accept_view(
            secondary_graph_dir, secondary_acceptance
        )
    _set_seed(config.seed)
    device = torch.device("cuda")
    model = SchNetWrapper(
        **ROUTE_B_SCHNET_CONFIG, use_charges=True, n_targets=3
    ).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
    )
    scaler = torch.amp.GradScaler("cuda")
    losses = []
    views = [primary_graph_dir]
    if variant == "augmented":
        views.append(secondary_graph_dir)
    torch.cuda.reset_peak_memory_stats()
    for graph_dir in views:
        graphs = torch.load(
            _graph_paths(graph_dir)[0], map_location="cpu", weights_only=False
        )[:batch_size]
        batch = next(iter(DataLoader(graphs, batch_size=batch_size))).to(device)
        optimizer.zero_grad(set_to_none=True)
        with torch.amp.autocast("cuda"):
            loss = nn.functional.l1_loss(
                _forward(model, batch), batch.y.view(-1, 3)
            )
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), config.grad_clip)
        scaler.step(optimizer)
        scaler.update()
        losses.append(float(loss.detach()))
    report = {
        "status": "complete",
        "variant": variant,
        "model_config": ROUTE_B_SCHNET_CONFIG,
        "input_reports": reports,
        "losses": losses,
        "finite": bool(np.isfinite(losses).all()),
        "device": torch.cuda.get_device_name(0),
        "peak_cuda_bytes": int(torch.cuda.max_memory_allocated()),
    }
    if not report["finite"]:
        raise RuntimeError("non-finite repaired-2M SchNet preflight")
    atomic_json(report, output_path)
    return report


def train_repaired_2m_schnet(
    *,
    primary_graph_dir: Path,
    primary_acceptance: Path,
    secondary_graph_dir: Path | None,
    secondary_acceptance: Path | None,
    output_dir: Path,
    config: Repaired2MSchNetConfig,
) -> dict:
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for repaired-2M SchNet training")
    input_reports = {
        "primary": _accept_view(primary_graph_dir, primary_acceptance)
    }
    secondary_paths = []
    if config.variant == "augmented":
        if secondary_graph_dir is None or secondary_acceptance is None:
            raise ValueError("augmented training requires the secondary view")
        input_reports["secondary"] = _accept_view(
            secondary_graph_dir, secondary_acceptance
        )
        secondary_paths = _graph_paths(secondary_graph_dir)
    primary_paths = _graph_paths(primary_graph_dir)
    roles = source_roles(config.source_rows, config.seed)
    _set_seed(config.seed)
    device = torch.device("cuda")
    model = SchNetWrapper(
        **ROUTE_B_SCHNET_CONFIG, use_charges=True, n_targets=3
    ).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=config.epochs, eta_min=1e-6
    )
    scaler = torch.amp.GradScaler("cuda")
    criterion = nn.L1Loss()
    output_dir.mkdir(parents=True, exist_ok=True)
    best_path = output_dir / "model.pt"
    last_path = output_dir / "checkpoint.pt"
    contract = {
        "config": asdict(config),
        "model_config": ROUTE_B_SCHNET_CONFIG,
        "input_reports": input_reports,
    }
    start_epoch = 0
    best_epoch = -1
    best_mae = float("inf")
    best_state = None
    wait = 0
    log = []
    if last_path.exists():
        checkpoint = torch.load(last_path, map_location=device, weights_only=False)
        if checkpoint.get("contract") != contract:
            raise RuntimeError("repaired-2M SchNet resume contract changed")
        model.load_state_dict(checkpoint["model"], strict=True)
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        scaler.load_state_dict(checkpoint["scaler"])
        best_state = checkpoint["best_state"]
        best_epoch = int(checkpoint["best_epoch"])
        best_mae = float(checkpoint["best_validation_average_mae_eV"])
        wait = int(checkpoint["wait"])
        log = list(checkpoint["log"])
        start_epoch = int(checkpoint["epoch"]) + 1

    training_paths = [("primary", path) for path in primary_paths]
    training_paths += [("secondary", path) for path in secondary_paths]
    for epoch in range(start_epoch, config.epochs):
        epoch_started = time.monotonic()
        model.train()
        total_loss = 0.0
        total_rows = 0
        paths = list(training_paths)
        random.Random(config.seed + epoch).shuffle(paths)
        for shard_index, (_, path) in enumerate(paths):
            graphs = torch.load(path, map_location="cpu", weights_only=False)
            selected = _role_graphs(graphs, roles, 0)
            del graphs
            if not selected:
                continue
            loader = DataLoader(
                selected,
                batch_size=config.batch_size,
                shuffle=True,
                num_workers=config.num_workers,
                pin_memory=True,
                generator=torch.Generator().manual_seed(
                    config.seed * 1_000_000 + epoch * 1_000 + shard_index
                ),
            )
            for batch in loader:
                batch = batch.to(device, non_blocking=True)
                optimizer.zero_grad(set_to_none=True)
                with torch.amp.autocast("cuda"):
                    loss = criterion(_forward(model, batch), batch.y.view(-1, 3))
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(
                    model.parameters(), config.grad_clip
                )
                scaler.step(optimizer)
                scaler.update()
                total_loss += float(loss.detach()) * batch.num_graphs
                total_rows += int(batch.num_graphs)
            del loader, selected
        validation_mae, validation_rows = _evaluate_role(
            model=model,
            graph_paths=primary_paths,
            roles=roles,
            role=1,
            device=device,
            batch_size=config.batch_size,
            num_workers=config.num_workers,
        )
        scheduler.step()
        average_mae = float(validation_mae.mean())
        improved = average_mae < best_mae
        if improved:
            best_mae = average_mae
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            wait = 0
        else:
            wait += 1
        row = {
            "epoch": epoch,
            "train_mae_eV": total_loss / max(total_rows, 1),
            "train_draw_rows": total_rows,
            "validation_rows": validation_rows,
            "validation_mae_eV": {
                name: float(validation_mae[index])
                for index, name in enumerate(("HOMO", "LUMO", "Gap"))
            },
            "validation_average_mae_eV": average_mae,
            "learning_rate": optimizer.param_groups[0]["lr"],
            "elapsed_s": time.monotonic() - epoch_started,
            "selected": improved,
        }
        log.append(row)
        atomic_torch_save(
            {
                "contract": contract,
                "epoch": epoch,
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(),
                "scaler": scaler.state_dict(),
                "best_state": best_state,
                "best_epoch": best_epoch,
                "best_validation_average_mae_eV": best_mae,
                "wait": wait,
                "log": log,
            },
            last_path,
        )
        atomic_json(
            {
                "status": "training",
                "variant": config.variant,
                "epoch": epoch,
                "best_epoch": best_epoch,
                "best_validation_average_mae_eV": best_mae,
            },
            output_dir / "progress.json",
        )
        print(
            f"{config.variant} ep{epoch:02d} "
            f"train={row['train_mae_eV']:.6f} "
            f"val={average_mae:.6f}eV {row['elapsed_s']:.1f}s"
            f"{' *' if improved else ''}",
            flush=True,
        )
        if wait >= config.patience:
            break
    if best_state is None:
        raise RuntimeError("repaired-2M SchNet produced no finite checkpoint")
    atomic_torch_save(best_state, best_path)
    model.load_state_dict(best_state, strict=True)
    test_mae, test_rows = _evaluate_role(
        model=model,
        graph_paths=primary_paths,
        roles=roles,
        role=2,
        device=device,
        batch_size=config.batch_size,
        num_workers=config.num_workers,
    )
    result = {
        "status": "complete",
        "variant": config.variant,
        "config": asdict(config),
        "model_config": ROUTE_B_SCHNET_CONFIG,
        "input_reports": input_reports,
        "best_epoch": best_epoch,
        "best_validation_average_mae_eV": best_mae,
        "test_rows": test_rows,
        "test_mae_eV": {
            name: float(test_mae[index])
            for index, name in enumerate(("HOMO", "LUMO", "Gap"))
        },
        "test_average_mae_eV": float(test_mae.mean()),
        "log": log,
        "artifacts": {
            "model": str(best_path),
            "model_sha256": sha256_file(best_path),
            "checkpoint": str(last_path),
            "checkpoint_sha256": sha256_file(last_path),
        },
    }
    atomic_json(result, output_dir / "metrics.json")
    atomic_json(
        {
            "status": "complete",
            "variant": config.variant,
            "model_sha256": result["artifacts"]["model_sha256"],
            "checkpoint_sha256": result["artifacts"]["checkpoint_sha256"],
        },
        output_dir / "completion_manifest.json",
    )
    return result


def export_repaired_2m_schnet_embeddings(
    *,
    root: Path,
    variant: str,
) -> dict:
    Repaired2MSchNetConfig(variant=variant)
    return export_embeddings(
        graph_dir=root / "primary" / "graph_shards",
        best_checkpoint=root / "outputs" / variant / "model.pt",
        output_dir=root / "embeddings" / variant,
        batch_size=128,
        num_workers=0,
        model_config=ROUTE_B_SCHNET_CONFIG,
    )


def accept_repaired_2m_schnet_embeddings(
    *,
    root: Path,
    output_path: Path,
    source_rows: int = 2_000_000,
) -> dict:
    variants = ("primary", "augmented")
    completions = {}
    for variant in variants:
        path = root / "embeddings" / variant / "completion.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        if payload.get("status") != "complete" or int(payload.get("parts", -1)) != 100:
            raise RuntimeError(f"incomplete embedding export: {variant}")
        completions[variant] = payload

    seen = np.zeros(source_rows, dtype=np.bool_)
    parts = []
    total_rows = 0
    for part_index in range(100):
        payloads = {}
        reports = {}
        for variant in variants:
            directory = root / "embeddings" / variant
            paths = sorted(directory.glob("embeddings_*.pt"))
            if len(paths) != 100:
                raise RuntimeError(f"{variant} embedding part count differs")
            path = paths[part_index]
            report_path = path.with_suffix(".json")
            report = json.loads(report_path.read_text(encoding="utf-8"))
            if report.get("sha256") != sha256_file(path):
                raise RuntimeError(f"embedding hash differs: {path}")
            payload = torch.load(path, map_location="cpu", weights_only=False)
            embeddings = payload["embeddings"]
            predictions = payload["predictions"]
            source_idx = payload["source_idx"].long()
            targets = payload["targets"].float()
            rows = len(source_idx)
            if (
                embeddings.shape != (rows, 176)
                or predictions.shape != (rows, 3)
                or targets.shape != (rows, 3)
            ):
                raise RuntimeError(f"embedding tensor shapes differ: {path}")
            if not all(
                torch.isfinite(tensor).all()
                for tensor in (embeddings, predictions, targets)
            ):
                raise RuntimeError(f"non-finite embedding payload: {path}")
            payloads[variant] = payload
            reports[variant] = {
                "path": path.name,
                "rows": rows,
                "sha256": report["sha256"],
            }
        primary = payloads["primary"]
        augmented = payloads["augmented"]
        if not torch.equal(primary["source_idx"], augmented["source_idx"]):
            raise RuntimeError(f"source_idx differs in embedding part {part_index}")
        if not torch.equal(primary["targets"], augmented["targets"]):
            raise RuntimeError(f"targets differ in embedding part {part_index}")
        indices = primary["source_idx"].numpy()
        if (indices < 0).any() or (indices >= source_rows).any():
            raise RuntimeError(f"source_idx outside contract in part {part_index}")
        if seen[indices].any():
            raise RuntimeError(f"duplicate source_idx in part {part_index}")
        seen[indices] = True
        rows = len(indices)
        total_rows += rows
        parts.append({"part": part_index + 1, "rows": rows, **reports})

    if total_rows != int(completions["primary"]["rows"]):
        raise RuntimeError("accepted embedding rows differ from primary completion")
    if total_rows != int(completions["augmented"]["rows"]):
        raise RuntimeError("accepted embedding rows differ from augmented completion")
    result = {
        "status": "accepted",
        "view": "primary_conformer_inference",
        "parts_per_variant": 100,
        "rows": total_rows,
        "source_rows": source_rows,
        "source_coverage": total_rows / source_rows,
        "embedding_dim": 176,
        "completions": completions,
        "parts": parts,
    }
    atomic_json(result, output_path)
    return result
