"""Static family differences for the shared, metadata-only output inspector.

These profiles describe the new output protocol, not every historical runner.
Registering one does not provide a trainer or authorize execution.
"""
from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType


@dataclass(frozen=True)
class ArtifactAdapter:
    name: str
    family: tuple[str, str]
    resume_keys: tuple[str, ...]
    ema_required: bool
    protocol: str = "screen"


ADAPTERS = MappingProxyType({
    "k1-session-v1": ArtifactAdapter("k1-session-v1", ("neural_atom_k1", "3"),
        ("model", "optimizer", "scheduler", "rng_state"), False, "family-session"),
    "gptrans-session-v1": ArtifactAdapter("gptrans-session-v1", ("gptrans_t", "2"),
        ("model", "optimizer", "scheduler", "rng_state"), False, "family-session"),
    "k1-screen-v1": ArtifactAdapter("k1-screen-v1", ("neural_atom_k1", "2"),
                                    ("model", "optimizer", "scheduler", "rng_state"), False),
    "k1-v1": ArtifactAdapter("k1-v1", ("neural_atom_k1", "1"),
                             ("model", "optimizer", "scheduler", "rng_state"), False),
    "gptrans-v1": ArtifactAdapter("gptrans-v1", ("gptrans_t", "1"),
                                  ("model", "ema", "optimizer", "rng_state"), True),
})


def artifact_adapter(name: str, family: tuple[str, str]) -> ArtifactAdapter:
    try:
        adapter = ADAPTERS[name]
    except (KeyError, TypeError) as exc:
        raise ValueError(f"Unsupported artifact adapter: {name}") from exc
    if adapter.family != family:
        raise ValueError("Artifact adapter/family mismatch")
    return adapter
