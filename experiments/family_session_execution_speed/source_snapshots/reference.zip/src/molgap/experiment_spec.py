"""Versioned prospective experiment contracts; no execution or readiness authority.

Registry versions describe this interface, not accepted model generations.
Digests bind declarations only: adapters must verify bytes, fixed recipe values,
role authorization and runtime certificates before using a spec to execute.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import PureWindowsPath
from types import MappingProxyType

from .screen_policy import canonical_fingerprint


SCHEMA_VERSION = "molgap-experiment-spec-v1"
SCHEMA_VERSION_V2 = "molgap-experiment-spec-v2"
TERMINAL_PROTOCOL = "molgap-experiment-terminal-descriptor-v1"
EDGE_STATE_BASE_LAYERS = 9
EDGE_STATE_MIN_LAYERS = 1
EDGE_STATE_MAX_LAYERS = 16


@dataclass(frozen=True)
class FamilyContract:
    """Static adapter lookup key and supported declaration contracts."""

    name: str
    version: str
    source_module: str
    recipe: str
    feature_schema: str
    roles: tuple[str, ...]
    sampler: str
    transform: str
    architecture_base: str | None = None
    optional_roles: tuple[str, ...] = ()


FAMILIES = MappingProxyType({
    ("neural_atom_k1", "3"): FamilyContract(
        "neural_atom_k1", "3", "molgap.family_training_runner", "shared-family-training",
        "ogb-atom9-bond3-rwse16-v1", ("train",), "frozen-family-pass-order",
        "frozen-train-mean-sample-std", "ogb_edge_state_structural_gps9", ("development",)),
    ("gptrans_t", "2"): FamilyContract(
        "gptrans_t", "2", "molgap.family_training_runner", "shared-family-training",
        "ogb-atom9-bond3-shortest-path-cap20", ("train",), "frozen-family-pass-order",
        "frozen-train-mean-sample-std", optional_roles=("development",)),
    ("edge_state_gps", "1"): FamilyContract(
        "edge_state_gps", "1", "molgap.edge_state_model_only_v1",
        "edge_state_model_only_v1", "ogb-atom9-bond3-rwse16-v1",
        ("train", "development"), "seed42-epoch-global-randperm-v1",
        "train-mean-unbiased-std", "ogb_edge_state_structural_gps9",
    ),
    ("gptrans_t", "1"): FamilyContract(
        "gptrans_t", "1", "molgap.gptrans", "pcqm_gptrans_v4",
        "ogb-atom9-bond3-shortest-path-cap20", ("train", "development"),
        "seed-plus-epoch-global-randperm-v1", "fixed-train-100k-mean-sample-std",
    ),
    ("neural_atom_k1", "1"): FamilyContract(
        "neural_atom_k1", "1", "molgap.qm9_neural_atom", "pcqm_k1_full",
        "ogb-atom9-bond3-rwse16-v1", ("train",),
        "seed42-global-randperm-by-pass-v1", "full-train-mean-sample-std",
        "ogb_edge_state_structural_gps9",
    ),
    ("neural_atom_k1", "2"): FamilyContract(
        "neural_atom_k1", "2", "molgap.k1_screen_training", "pcqm_k1_v4_100k",
        "ogb-atom9-bond3-rwse16-v1", ("train", "development"),
        "seed42-python-epoch-shuffle-v4", "fixed-train-100k-mean-sample-std",
        "ogb_edge_state_structural_gps9",
    ),
})


@dataclass(frozen=True)
class AddonContract:
    family: str
    exclusive_group: str
    source_module: str


# Each family's replacement group is exclusive; stacking is not supported.
ADDONS = MappingProxyType({
    ("edge_state_depth", "1"): AddonContract(
        "edge_state_gps", "edge-state-architecture", "molgap.edge_state_model_only_v1",
    ),
    ("neural_atom_k1", "1"): AddonContract(
        "edge_state_gps", "edge-state-architecture", "molgap.qm9_neural_atom",
    ),
    **{
        (name, "1"): AddonContract("gptrans_t", "attention-replacement", "molgap.gptrans_variants")
        for name in ("pair_prenorm", "centered_logits")
    },
    **{
        (name, "1"): AddonContract("gptrans_t", "attention-replacement", "molgap.gptrans_memory")
        for name in ("memory_value", "memory_message")
    },
    ("k1_pair_value", "1"): AddonContract(
        "neural_atom_k1", "pair-token-replacement", "molgap.k1_pair_token",
    ),
    ("k1_joint_aggregation", "1"): AddonContract(
        "neural_atom_k1", "k1-local-aggregation", "molgap.k1_joint_aggregation",
    ),
    ("k1_two_pass_mean", "1"): AddonContract(
        "neural_atom_k1", "k1-training-objective", "molgap.k1_screen_training",
    ),
    ("k1_mean2_clean_second", "1"): AddonContract(
        "neural_atom_k1", "k1-training-objective", "molgap.k1_screen_training",
    ),
    # Historical declaration compatibility only; live training dispatch retires these.
    ("k1_fused_layout", "1"): AddonContract(
        "neural_atom_k1", "k1-execution", "molgap.k1_screen_training",
    ),
    ("k1_initialized_layout", "1"): AddonContract(
        "neural_atom_k1", "k1-execution", "molgap.k1_screen_training",
    ),
})


def _object(value, fields: str, path: str) -> dict:
    if type(value) is not dict or set(value) != set(fields.split()):
        raise ValueError(f"{path}: expected exactly fields [{fields}]")
    return value


def _text(value, path: str) -> None:
    if type(value) is not str or not value.strip() or value != value.strip():
        raise ValueError(f"{path}: expected nonempty trimmed string")


def _digest(value, path: str) -> None:
    if type(value) is not str or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError(f"{path}: expected lowercase SHA-256")


def _identifier(value, path: str) -> None:
    if type(value) is not str or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", value):
        raise ValueError(f"{path}: expected safe identity")


def _integer(value, path: str, minimum: int = 1) -> None:
    if type(value) is not int or value < minimum:
        raise ValueError(f"{path}: expected integer >= {minimum}")


def _choice(value, choices, path: str) -> None:
    if type(value) is not str or value not in choices:
        raise ValueError(f"{path}: unsupported value {value!r}")


def _reference(value, path: str, *, name: str | None = None) -> None:
    _object(value, "name version sha256", path)
    _text(value["name"], path + ".name")
    _choice(value["version"], ("1",), path + ".version")
    _digest(value["sha256"], path + ".sha256")
    if name is not None and value["name"] != name:
        raise ValueError(f"{path}: expected {name}")


def _list(value, path: str, *, nonempty: bool = True) -> None:
    if type(value) is not list or (nonempty and not value):
        raise ValueError(f"{path}: expected {'nonempty ' if nonempty else ''}array")


def _repo_path(value, path: str, *, output: bool = False) -> None:
    _text(value, path)
    if ("\\" in value or ":" in value or value.startswith("/")
            or PureWindowsPath(value).drive or PureWindowsPath(value).root):
        raise ValueError(f"{path}: expected repository-relative POSIX path")
    parts = value.split("/")
    for part in parts:
        if (part in {"", ".", ".."} or part.endswith((" ", "."))
                or any(ord(char) < 32 or char in '<>"|?*' for char in part)
                or PureWindowsPath(part).is_reserved()):
            raise ValueError(f"{path}: unsafe path component")
    if output:
        if len(parts) < 2 or parts[0] != "experiments":
            raise ValueError(f"{path}: output must be below experiments/")
    elif not value.endswith(".json"):
        raise ValueError(f"{path}: expected JSON plan input")


def _arm(arm: dict) -> None:
    _object(arm, "arm_id scientific_role family base initialization data training addons addon_semantics", "arm")
    _identifier(arm["arm_id"], "arm.arm_id")
    _choice(arm["scientific_role"], ("reference", "candidate", "ablation"), "arm.scientific_role")
    family = _object(arm["family"], "name version", "family")
    _text(family["name"], "family.name")
    _text(family["version"], "family.version")
    contract = FAMILIES.get((family["name"], family["version"]))
    if contract is None:
        raise ValueError("Unknown family/version")
    _reference(arm["base"], "base")
    init = _object(arm["initialization"], "kind seed state_sha256", "initialization")
    _choice(init["kind"], ("random", "frozen_state"), "initialization.kind")
    _integer(init["seed"], "initialization.seed", 0)
    _digest(init["state_sha256"], "initialization.state_sha256")

    data = _object(arm["data"], "dataset split roles feature_schema feature_sha256 target", "data")
    _reference(data["dataset"], "data.dataset", name="pcqm4mv2")
    _reference(data["split"], "data.split")
    _choice(data["feature_schema"], (contract.feature_schema,), "data.feature_schema")
    _digest(data["feature_sha256"], "data.feature_sha256")
    _choice(data["target"], ("pcqm4mv2-gap-eV-direct",), "data.target")
    _list(data["roles"], "data.roles")
    roles = []
    for role in data["roles"]:
        _object(role, "role membership_sha256 row_order_sha256 usage_sha256", "data.role")
        _choice(role["role"], (*contract.roles, *contract.optional_roles), "data.role.role")
        for field in ("membership_sha256", "row_order_sha256", "usage_sha256"):
            _digest(role[field], "data.role." + field)
        roles.append(role["role"])
    if (len(set(roles)) != len(roles) or not set(contract.roles) <= set(roles)
            or not set(roles) <= set(contract.roles + contract.optional_roles)):
        raise ValueError("Data roles must match the recipe exactly, without duplicates")

    training = _object(arm["training"], "recipe overrides objective sampler transform", "training")
    _reference(training["recipe"], "training.recipe", name=contract.recipe)
    # Frozen legacy recipes have no override allowance. A reviewed new recipe
    # version must define typed bounds before any override can become executable.
    _object(training["overrides"], "", "training.overrides")
    explicit_k1_replication = family == {"name": "neural_atom_k1", "version": "2"} and init["seed"] == 43
    shared_family = (family["name"], family["version"]) in {("neural_atom_k1", "3"), ("gptrans_t", "2")}
    if init["seed"] != 42 and not explicit_k1_replication and not shared_family:
        raise ValueError("Frozen recipe initialization requires seed 42")
    _reference(training["objective"], "training.objective", name="normalized-gap-l1")
    sampler_name = "seed43-python-epoch-shuffle-v4" if explicit_k1_replication else contract.sampler
    _reference(training["sampler"], "training.sampler", name=sampler_name)
    _reference(training["transform"], "training.transform", name=contract.transform)

    _list(arm["addons"], "addons", nonempty=False)
    expected = "ordered" if arm["addons"] else "baseline"
    _choice(arm["addon_semantics"], (expected,), "addon_semantics")
    groups = set()
    for addon in arm["addons"]:
        _object(addon, "name version config source_sha256", "addon")
        _text(addon["name"], "addon.name")
        _text(addon["version"], "addon.version")
        extension = ADDONS.get((addon["name"], addon["version"]))
        if extension is None:
            raise ValueError("Unknown addon/version")
        if extension.family != contract.name or extension.exclusive_group in groups:
            raise ValueError("Incompatible addon combination/family")
        groups.add(extension.exclusive_group)
        if addon["name"] == "edge_state_depth":
            config = _object(addon["config"], "num_layers", "addon.config")
            _integer(config["num_layers"], "addon.config.num_layers")
            if (not EDGE_STATE_MIN_LAYERS <= config["num_layers"] <= EDGE_STATE_MAX_LAYERS
                    or config["num_layers"] == EDGE_STATE_BASE_LAYERS):
                raise ValueError(
                    f"edge_state_depth requires num_layers in "
                    f"[{EDGE_STATE_MIN_LAYERS}, {EDGE_STATE_MAX_LAYERS}] "
                    f"except {EDGE_STATE_BASE_LAYERS}"
                )
        elif addon["name"] == "k1_joint_aggregation":
            if family["version"] not in {"2", "3"} or len(arm["addons"]) != 1:
                raise ValueError("K1 screen extension requires family/version 2 and one extension")
            if addon["config"] != {"layer": 6, "latent_channels": 64, "kappa": 4,
                                    "seed": init["seed"] if shared_family else 42,
                                    "degree_policy": "original-sum-above-four"}:
                raise ValueError("K1 extension differs from the bounded frozen configuration")
        elif addon["name"] in {"k1_two_pass_mean", "k1_mean2_clean_second", "k1_fused_layout",
                               "k1_initialized_layout"}:
            versions = {"2", "3"} if addon["name"] in {"k1_two_pass_mean", "k1_mean2_clean_second"} else {"2"}
            if family["version"] not in versions or len(arm["addons"]) != 1 or addon["config"] != {}:
                raise ValueError("K1 screen addon requires family v2 and no additional change")
        else:
            _object(addon["config"], "", "addon.config")
        _digest(addon["source_sha256"], "addon.source_sha256")


def validate_experiment_spec(payload: dict) -> dict:
    """Return a detached strict JSON declaration; never certify runtime/evidence."""
    spec = _object(payload, "schema_version experiment_id logical_run_id arms platform prospective evidence terminal_protocol", "spec")
    _choice(spec["schema_version"], (SCHEMA_VERSION, SCHEMA_VERSION_V2), "schema_version")
    _identifier(spec["experiment_id"], "experiment_id")
    _identifier(spec["logical_run_id"], "logical_run_id")
    _choice(spec["terminal_protocol"], (TERMINAL_PROTOCOL,), "terminal_protocol")
    _list(spec["arms"], "arms")
    for arm in spec["arms"]:
        _arm(arm)
    ids = [arm["arm_id"] for arm in spec["arms"]]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate arm_id")
    platform = _object(spec["platform"], "name accelerator device_count cpu_cores memory_gib atomic_checkpoints retrievable_chunks", "platform")
    _choice(platform["name"], ("local", "kaggle", "scnet", "ims", "colab"), "platform.name")
    _text(platform["accelerator"], "platform.accelerator")
    for field in ("device_count", "cpu_cores", "memory_gib"):
        _integer(platform[field], "platform." + field)
    # Device count declares resources; runner/platform gates must verify arm,
    # process and visible-device isolation before execution.
    for field in ("atomic_checkpoints", "retrievable_chunks"):
        if platform[field] is not True:
            raise ValueError("Durability requirements cannot be disabled")
    if spec["schema_version"] == SCHEMA_VERSION:
        prospective = _object(spec["prospective"], "trajectory_id hypothesis cheapest_falsifier stop_rule budget_sha256", "prospective")
        _identifier(prospective["trajectory_id"], "prospective.trajectory_id")
        for field in ("hypothesis", "cheapest_falsifier", "stop_rule"):
            _text(prospective[field], "prospective." + field)
        _digest(prospective["budget_sha256"], "prospective.budget_sha256")
    else:
        prospective = spec["prospective"]
        if type(prospective) is not dict or set(prospective) not in ({"arms"}, {"arms", "same_run_replay"}):
            raise ValueError("prospective: expected arms and optional same_run_replay")
        _list(prospective["arms"], "prospective.arms")
        mapped_ids = []
        trajectory_ids = set()
        outputs = set()
        for entry in prospective["arms"]:
            _object(entry, "arm_id trajectory_id plan_spec_ref plan_spec_sha256 output", "prospective.arm")
            for field in ("arm_id", "trajectory_id"):
                _identifier(entry[field], "prospective.arm." + field)
            _digest(entry["plan_spec_sha256"], "prospective.arm.plan_spec_sha256")
            _repo_path(entry["plan_spec_ref"], "prospective.arm.plan_spec_ref")
            _repo_path(entry["output"], "prospective.arm.output", output=True)
            mapped_ids.append(entry["arm_id"])
            if entry["trajectory_id"] in trajectory_ids:
                raise ValueError("Duplicate prospective trajectory_id")
            trajectory_ids.add(entry["trajectory_id"])
            output_key = entry["output"].casefold()
            if output_key in outputs:
                raise ValueError("Duplicate prospective output")
            outputs.add(output_key)
        if len(mapped_ids) != len(set(mapped_ids)) or set(mapped_ids) != set(ids):
            raise ValueError("Prospective arm mapping must match spec arms exactly once")
        if "same_run_replay" in prospective:
            paired = _object(prospective["same_run_replay"], "reference_arm_id candidate_arm_ids", "prospective.same_run_replay")
            _identifier(paired["reference_arm_id"], "prospective.same_run_replay.reference_arm_id")
            _list(paired["candidate_arm_ids"], "prospective.same_run_replay.candidate_arm_ids")
            for candidate_id in paired["candidate_arm_ids"]:
                _identifier(candidate_id, "prospective.same_run_replay.candidate_arm_ids")
            if len(set(paired["candidate_arm_ids"])) != len(paired["candidate_arm_ids"]):
                raise ValueError("Duplicate same-run candidate arm")
            roles = {arm["arm_id"]: arm["scientific_role"] for arm in spec["arms"]}
            if roles.get(paired["reference_arm_id"]) != "reference" or any(
                roles.get(candidate_id) != "candidate" for candidate_id in paired["candidate_arm_ids"]
            ):
                raise ValueError("same-run replay arms must declare reference and candidate roles")
    evidence = _object(spec["evidence"], "policy required_artifacts", "evidence")
    _reference(evidence["policy"], "evidence.policy", name="molgap-v5")
    _list(evidence["required_artifacts"], "evidence.required_artifacts")
    required = {"v5_evidence", "costs", "roles", "trace_manifest", "terminal_artifact"}
    for item in evidence["required_artifacts"]:
        _choice(item, required, "evidence.required_artifacts")
    if set(evidence["required_artifacts"]) != required or len(evidence["required_artifacts"]) != len(required):
        raise ValueError("Evidence requirements must be complete and unique")
    return json.loads(_canonical(spec))


def _canonical(value: dict) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def _unique_object(pairs) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON field: {key}")
        result[key] = value
    return result


@dataclass(frozen=True, init=False)
class ExperimentSpec:
    """Immutable validated canonical snapshot for future adapters and packaging."""

    _canonical_json: str

    def __init__(self, payload: dict):
        object.__setattr__(self, "_canonical_json", _canonical(validate_experiment_spec(payload)))

    @classmethod
    def from_json(cls, text: str) -> ExperimentSpec:
        return cls(json.loads(text, object_pairs_hook=_unique_object))

    def to_dict(self) -> dict:
        return json.loads(self._canonical_json)

    def to_json(self) -> str:
        return self._canonical_json

    @property
    def identity(self) -> str:
        return canonical_fingerprint(self.to_dict())

    def family_contract(self, arm_id: str) -> FamilyContract:
        """Resolve a static contract without importing or running model code."""
        for arm in self.to_dict()["arms"]:
            if arm["arm_id"] == arm_id:
                family = arm["family"]
                return FAMILIES[(family["name"], family["version"])]
        raise ValueError(f"Unknown arm: {arm_id}")
